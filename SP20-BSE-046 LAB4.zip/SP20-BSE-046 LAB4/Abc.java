/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotdog1;

/**
 *
 * @author Windows
 */
public class Abc {
     public static void main(String[] args) {
        HotDogStand stand1 = new HotDogStand(1, 11);
        HotDogStand stand2 = new HotDogStand(2, 17);
        HotDogStand stand3 = new HotDogStand(3, 6);

        stand1.getID();
        stand2.getID();
        stand3.getID();
        stand1.setID(1);
        stand2.setID(2);
        stand3.setID(3);
        stand1.justSold();
        stand2.justSold();
        stand3.justSold();
        stand1.justSold();
        stand1.justSold();
        stand1.justSold();
        stand3.justSold();

        stand1.getTotal();
        stand2.getTotal();
        stand3.getTotal();

        int grandTotal = stand1.getTotal() + stand2.getTotal() + stand3.getTotal();

        System.out.println("Stand " + stand1.getID() + " sold a total of " + stand1.getTotal() + " hotdogs.");
        System.out.println("Stand " + stand2.getID() + " sold a total of " + stand2.getTotal() + " hotdogs.");
        System.out.println("Stand " + stand3.getID() + " sold a total of " + stand3.getTotal() + " hotdogs.");

        System.out.println("The total amount of hotdogs sold by all the stands was " + grandTotal);
    }
    
}
