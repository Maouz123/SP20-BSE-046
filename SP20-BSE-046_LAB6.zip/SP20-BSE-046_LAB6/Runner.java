/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;
import java.util.Scanner;

/**
 *
 * @author Windows
 */
public class Runner {
    public static void main(String[] args) {
        double num1 ,num2,angle;
        Scanner input = new Scanner(System.in);
        Cal c=new Cal();
        System.out.print("Enter x: ");
        num1=input.nextDouble();
        c.getx(num1);
        System.out.print("Enter y: ");
        num2=input.nextDouble();
        c.gety(num2);
        System.out.println(c.getx(num1)+" + "+c.gety(num2)+" =: " + Cal.sum(c.getx(num1),c.gety(num2)));
     
        System.out.println(c.getx(num1)+" x "+c.gety(num2)+" =: " + Cal.multiply(c.getx(num1),c.gety(num2)));
        System.out.println(c.getx(num1)+" / "+c.gety(num2)+" =: " + Cal.divide(c.getx(num1),c.gety(num2)));
        System.out.println(c.getx(num1)+" % "+c.gety(num2)+" =: " + Cal.modulus(c.getx(num1),c.gety(num2)));
        System.out.print("Enter the angle: ");
        angle =input.nextDouble();
        System.out.println("sin of ("+angle+") =: "+Cal.sin(angle));
        System.out.println("cos of ("+angle+") =: "+Cal.cos(angle));
        System.out.println("tan of ("+angle+") =: "+Cal.tan(angle));
        input.close();/*
        
        */
    }

}
