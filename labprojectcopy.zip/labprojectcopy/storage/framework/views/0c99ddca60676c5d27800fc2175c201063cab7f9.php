<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatibile" content="ie=edge">
  <meta name="Description" content="Enter your description here"/>
  <title>Cafe</title>
  <!-- bootstrap CDN-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Smooch&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet"  type="text/css">
<!-- CSS-->
<link rel="stylesheet" href="/admincss/style.css">
<link rel="stylesheet" href="/admincss/responsive-style.css">
</head>

<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="100"> 
  <!--Header-->
  <header>
    <nav class="navbar navbar-expand-lg navigation-wrap">
      <div class="container">
        <a class="navbar-brand" href="#">
          <h2 style="font-family:Smooch ; font-size:55px; margin-left: 30px; ">Cafê</h2>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <!--  <span class="navbar-toggler-icon"></span>-->
         <i class="fas fa-stream navbar-toggler-icon "></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            
            <li><a href="#" ><button class="main-btn" >Logout</button></a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  <div class="wrapper">
    <div class="sidebar">
    
        <img class="adminlogo" src="/Images/admin.png">
        
        <ul>
            <li ><a  href="index.html"><i class="fas fa-home"></i>Home</a></li>
            <li><a href="#"><i class="fas fa-user"></i>Profile</a></li>
           
            <li><a href="orders.html"><i class="fa-solid fa-basket-shopping"></i>Orders</a></li>
            <li><a href="contact.html"><i class="fa-solid fa-clipboard-list"></i></i>Queries</a></li>
            <li><a href="customers.html"><i class="fa-solid fa-people-group"></i>Customers</a></li>
            <li id="active" ><a href="viewmenu.html"><i class="fa-solid fa-bell-concierge"></i>Menu Items</a></li>
            <li><a href="gallery.html"><i class="fa-solid fa-camera-retro"></i>Gallery</a></li>
        </ul> 
      
    </div>
   
</div>
<!--form-->
  <h2 class="pnd">Edit Image</h2>
  <a href='/viewgall'><button class="btncompord" id="mm"  >View Gallery</button></a> 
<div class="divform">
  
<form action="/updimg" method="POST" name="sentMessage" id="contactForm" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" id="id" name="id" value="<?php echo e($itm['img_id']); ?>"><br>
    <label for="fname">Name</label><br>
    <input type="text" id="fname" name="name" value="<?php echo e($itm['title']); ?> "><br>

    <label for="lname">Description</label><br>
    <input type="text" id="lname" name="description" value="<?php echo e($itm['description']); ?>"><br>

    
    <label  >Image</label><br>
    <img src="<?php echo e("/Images/".$itm['image']); ?>" style="width:90px; height=50px;"><br><br>
    <input type="file" id="img" name="photo" ><br>
  
    <input type="submit" value="Submit">
  </form>
</div>
</body>
</html>
  

 
 <?php /**PATH D:\Sem 6\workspace\labproject\resources\views/admin/editgallery.blade.php ENDPATH**/ ?>