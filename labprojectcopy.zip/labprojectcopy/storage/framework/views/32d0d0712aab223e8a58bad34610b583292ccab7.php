<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatibile" content="ie=edge">
  <meta name="Description" content="Enter your description here"/>
  <title>Cafe</title>
  <!-- bootstrap CDN-->
  
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet"  type="text/css">

<!-- CSS-->
<link rel="stylesheet" href="/admincss/style.css">
<link rel="stylesheet" href="/admincss/responsive-style.css">
<link rel="stylesheet" href="/admincss/admin_style.css">
<link rel="stylesheet" href="/css/adminresponsive-style.css">

<link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Smooch&display=swap" rel="stylesheet">
<style>

</style>


</head>

<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="100"> 
  <!--Header-->
  <header>
    <nav class="navbar navbar-expand-lg navigation-wrap">
      <div class="container">
        <a class="navbar-brand" href="#">
          <h2 style="font-family:Smooch ; font-size:55px; margin-left: 30px; ">Cafê</h2>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <!--  <span class="navbar-toggler-icon"></span>-->
         <i class="fas fa-stream navbar-toggler-icon "></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            
            <li><a href="/" ><button class="main-btn" >Logout</button></a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <div class="wrapper">
    <div class="sidebar">
    
        <img class="adminlogo" src="/Images/admin.png">
        
      
        <ul>
            <li id="active" ><a  href="/adminindex"><i class="fas fa-home"></i>Home</a></li>
            <li><a href="/adminprofile"><i class="fas fa-user"></i>Profile</a></li>
           
            <li><a href="/vieworders"><i class="fa-solid fa-basket-shopping"></i>Orders</a></li>
            <li><a href="/qlist"><i class="fa-solid fa-clipboard-list"></i>Queries</a></li>
            <li><a href="/customer"><i class="fa-solid fa-people-group"></i>Customers</a></li>
            <li><a href="/itmlist"><i class="fa-solid fa-bell-concierge"></i>Menu Items</a></li>
            <li><a href="/viewgall"><i class="fa-solid fa-camera-retro"></i>Gallery</a></li>
        </ul>  
      
    </div>
 
  <div class="main_content">
    <h2 class="cus">Query</h2>

  
    <form action="/viewquery" method="POST" name="sentMessage" id="query_form" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
      
    <div class="query-labels">
    <input type="hidden"  name=id value=" <?php echo e($d['query_id']); ?>">
          <label type="text"  >Name: <?php echo e($d['name']); ?></label>
    </div>
      
      <div class="query-labels">
        <label type="text"   >Email: <?php echo e($d['email']); ?></label>
      </div>
      <div class="query-labels">
        <label type="text" >Subject: <?php echo e($d['subject']); ?></label>
      </div>
      <div class="query-labels">
        <label type="text"  >Message:  <?php echo e($d['message']); ?></label>
      </div>
      <div class="query-labels">
        <label type="text"  >Date:  <?php echo e($d['date']); ?></label>
      </div>
      <div class="query-labels">
        <label type="text"  >Reply: </label>
      </div>
      <div class="control-group">
          <textarea class="form-control" rows="6" id="message" name="reply"  required > <?php echo e($d['reply']); ?></textarea>
          <p class="help-block text-danger"></p>
      </div>
  
       
    <button class="main-btn" type="submit" id="query-btn">Send Message</button>
         

    
  </form>
  
</div>
</body>
</html>
<?php /**PATH C:\Users\Aneeza Amanat\Desktop\labproject\resources\views/admin/viewquery.blade.php ENDPATH**/ ?>