<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use Session;
use DateTime; 
use App\Models\order;
use App\Models\item;
use view\beverages;

 class Cart
    {
        
     


       public function cart($id){
       
        $data = item::find($id);
         $name=$data->name;
         $price=$data->price;
         $quantity=2;

       $cart= array(array($id, $name, $price, $quantity));
                    $items=array
                    (
                    array(1,"Mocha",100, 1),
                    array(2,"Mocha2",100, 1),
                    array(3,"Red Velvet Cake",250, 1),
                    array(4,"Macrons",250, 1),
                    );
                    
            for($i=0; $i<sizeof($cart); $i++){
                for($j=0; $j<=i; $j++){
                    if($name==$items[$i][$j]){
                        display();
                    }


                }
       
            }
            return view(cart);

                }
                

        
        function display(){
            for($i=0; $i<sizeof($items); $i++){
                for($j=0; $j<=i; $j++){
                    echo($j);

        }
    }

        }}

?>