/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotdog1;

/**
 *
 * @author Windows
 */
public class HotDogStand {
     private int IDNumber;
    private int hotDogsSold = 0;
    private static int totalSold = 0;

    public HotDogStand(int ID, int sold) {
        IDNumber = ID;
        hotDogsSold = sold;
    }

    public int getID() {
        return IDNumber;
    }

    public void setID(int ID) {
        IDNumber = ID;
    }

    public void justSold() {
        if (hotDogsSold > 0) {
            hotDogsSold++;
        }
    }

    public int sold() {
        return hotDogsSold;
    }

    public static int getTotal() {
        return totalSold;
    }
    
}
