/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;

/**
 *
 * @author Windows
 */
public class Runner {
     public static void main(String[] args) {
            PhdStudent s1=new PhdStudent();
            GradStudent s2=new GradStudent();
            s1.A();
            s2.A();
        }
    
}
