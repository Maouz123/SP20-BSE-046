/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package publishing_company;

/**
 *
 * @author Windows
 */
public class book extends Publishing_Company{
     private int pageCount;

    public book() {

    }
    public book(int pageCount){
        this.pageCount = pageCount;
    }
    public void setPageCount(int pageCount){
        this.pageCount = pageCount;
    }
    public int getPageCount(){
        return pageCount;
    }
    @Override
    public void display(){
        System.out.println("the number of Pages are: " + getPageCount());
    }
}
