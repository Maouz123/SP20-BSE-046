/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package publishing_company;

/**
 *
 * @author Windows
 */
public class Publishing_Company {
    private String title;
    private double price;
    public Publishing_Company (){

    }
    
    public Publishing_Company (String title, double price){
        this.title = title;
        this.price = price;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public void setPrice(double price){
        this.price = price;
    }
    public String getTitle(){
        return title;
    }
    public double getPrice(){
        return price;
    }
    public void display(){
        System.out.println("Title:"+getTitle()+getPrice());
    }
}
