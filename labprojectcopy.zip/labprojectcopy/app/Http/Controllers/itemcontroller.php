<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\item;
class itemcontroller extends Controller
{
    function save(Request $request){
       $data= new item;
        $data->name=$request->input('name');
        $data->description=$request->input('description');
        $data-> category=$request->input('category');
        $data->price=$request->input('price');
        
       
       $path="Images/";
        $data->img=$path.$request->image->getClientOriginalName();
        $data->save();
        return redirect('/item');
      
    }
    function view(){
     
        $data= item::all();
        return view('admin/viewitems',['items'=>$data]);
        
      }

      
      function delitm($id){
        $data= item::find($id);
        $data->delete();
        return redirect('/itmlist');
      }
      
      function showitm($id){
        $data= item::find($id);
       
        return view('admin/edititm',['itm'=>$data]);
      }
      function updateitm(Request $request){
         $data= item::find($request->id);
         $data->name=$request->input('name');
         $data->description=$request->input('description');
         $data-> category=$request->input('category');
         $data->price=$request->input('price');
         if($request->image!=null){
         $path="Images/";
         $data->img=$path.$request->image->getClientOriginalName();}
         $data->save();
         return redirect('/itmlist');
       
     }

     function beverages(){
     
      $data= item::all();
    
      return view('beverages',['items'=>$data]);
      
    }
    function snacks(){
     
      $data= item::all();
    
      return view('snacks',['items'=>$data]);
      
    }
    function desserts(){
     
      $data= item::all();
    
      return view('desserts',['items'=>$data]);
      
    }
    function deals(){
     
      $data= item::all();
    
      return view('deals',['items'=>$data]);
      
    }



}
