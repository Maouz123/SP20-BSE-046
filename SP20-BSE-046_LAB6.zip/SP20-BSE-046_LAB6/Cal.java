/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author Windows
 */
public class Cal {
    private double x;
    private double y;
    public double angle;
    
    
    public Cal(){
    }
    public Cal(double  x,double y){
        x=x;
        y=y;
        
    }
    public void setx(){
        x=x;
    }
    public double getx(double x){
        return x;
    }
    public void sety(){
        y=y;
    }
    public double gety(double y){
        return y;
    }
    
    public static double sum(double x, double y) {
        return x + y;
    }
    public static double multiply(double x, double y){
        return x * y;
    }
    public static double divide(double x, double y){
        return x / y;
    }
    public static double modulus(double x, double y){
        return x % y;
    }
    public static double sin(double x){
        return Math.sin(x);
    }
    public static double cos(double x){
        return Math.cos(x);
    }
    public static double tan(double x){
        return Math.tan(x);
    }
}
