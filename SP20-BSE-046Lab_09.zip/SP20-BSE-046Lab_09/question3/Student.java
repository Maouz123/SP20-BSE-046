/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;

/**
 *
 * @author Windows
 */
abstract class Student{
    public void A(){
        System.out.println("Hello");
    }
}

class PhdStudent extends Student{
    @Override
    public void A(){
        System.out.println("fine");
    }
}

class GradStudent extends Student{
    @Override
    public void A(){
        System.out.println("thx");
    }


}
