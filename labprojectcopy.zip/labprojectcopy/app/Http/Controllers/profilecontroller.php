<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Models\customer;
use App\Models\order;
use App\Models\register;
class profilecontroller extends Controller

{
    public function displayprofile(Request $request){
        $data=admin::all();
        return redirect('/adminprofile', ['admins'=>$data]);
}

}