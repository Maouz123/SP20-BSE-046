/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computer;

/**
 *
 * @author Windows
 */
public class Computer {
    private double wordsize;
    private double memorysize;
    private double storagesize;
    private double speed;

    public Computer(){

    }
    public Computer(double wordsize, double memorysize, double storagesize, double speed){
        this.wordsize = wordsize;
        this.memorysize = memorysize;
        this.storagesize = storagesize;
        this.speed = speed;
    }
    public void setwordsize(){
        this.wordsize=wordsize;
        
    }
    public double getwordsize(){
        return this.wordsize=wordsize;
        
    }
    public void setmemorysize(){
        this.memorysize=memorysize;
        
    }
    public double getmemorysize(){
        return this.memorysize=memorysize;
        
    }
    public void setstoragesize(){
        this.storagesize=storagesize;
        
    }
    public double getstoragesize(){
        return this.storagesize=storagesize;
        
    }
    public void setspeed(){
        this.wordsize=wordsize;
        
    }
    public double getspeed(){
        return this.wordsize=wordsize;
        
    }
    
    public void display(){
        System.out.println("Word size: " + wordsize+"bits\nMemory size: " + this.memorysize+"Mb\nStorages: " + this.storagesize+"Mb\nSpeed: " + this.speed+"Mhz");
    }

}
