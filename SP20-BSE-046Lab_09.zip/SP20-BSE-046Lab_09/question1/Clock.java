/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clock;

/**
 *
 * @author Windows
 */
public class Clock {
     String hours, minutes, seconds;
     public Clock(){
         
     }
    public Clock(String hrs, String mins, String secs){
        this.hours=hrs;
        this.minutes=mins;
        this.seconds=secs;
    }
    public void sethours(){
        this.hours=hours;
        
    }
    public String gethours(){
        return this.hours;
    }
    public void setminutes(){
        this.minutes=minutes;
        
    }
    public String getminutes(){
        return this.minutes;
    }
    public void setseconds(){
        this.seconds=seconds;
        
    }
    public String getseconds(){
        return this.seconds;
    }
    //display method to display the time in 24 hour Format
    public void display(){
        System.out.println("The given clock time is; "+this.hours+":"+this.minutes+":"+this.seconds);
    }
    
}
