<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatibile" content="ie=edge">
  <meta name="Description" content="Enter your description here"/>
  <title>Cafe</title>
  <!-- bootstrap CDN-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Smooch&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet"  type="text/css">
<!-- CSS-->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive-style.css">
<link rel="stylesheet" href="css/indx.css">

</head>

<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="100"> 
  <!--Header-->
  <header>
  <nav class="navbar navbar-expand-lg navigation-wrap">
      <div class="container">
        <a class="navbar-brand" href="#">
          <h2 style="font-family:Smooch ; font-size:55px; ">Cafê</h2>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <!--  <span class="navbar-toggler-icon"></span>-->
         <i class="fas fa-stream navbar-toggler-icon "></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
           
            <li><a href="/adminlogin" ><button class="main-btn" >Sign-in</button></a></li>
           
          </ul>
        </div>
      </div>
    </nav>
  </header>
  <div class="login-box">
  <img class="avatar1" src="Images/admin.png">
     

<h2 class="hlogin">Sign-in</h2>
<div id="error" style="color:red ; font-size:small; "></div>
<form action="/adminlogin" method="POST" name="sentMessage" id="signinform">
  <?php echo csrf_field(); ?>
        <p>Username</p>
        <input type="text" class="" id="name" name="first_name" placeholder="Enter Username:"  required />
        <p>Password</p>
        <input  class="" id="password"  name="password" type="password" placeholder="Enter Password:" required/><br>
        <button class="btn btn-primary" type="submit" id="sendbtn" ><a href="/adminindex">Login</a></button><br>
        <a href="/adminregister">Lost your password</a><br>
        <a href="/adminregister">Don't have an account?</a><br>

</form>
</div>
</body>
</html>



<?php /**PATH C:\Users\Aneeza Amanat\Desktop\labproject\resources\views//admin/adminlogin.blade.php ENDPATH**/ ?>