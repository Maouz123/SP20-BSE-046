/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizza;

/**
 *
 * @author Windows
 */
public class Pizza { 
    private String size_of_pizza;
    private int number_of_cheese_topping;
    private int number_of_pepperoni_topping;
    private int number_of_ham_topping;
    public Pizza(String size, int cheese, int pepperoni, int ham){
        this.size_of_pizza = size;
        this.number_of_cheese_topping = cheese;
        this.number_of_pepperoni_topping = pepperoni;
        this.number_of_ham_topping= ham;
    }
    public void set(String size){
        this.size_of_pizza = size;
    }
    public void setNumberOfCheese(int cheese){
        this.number_of_cheese_topping  = cheese;
    }
    public void setNumberOfPepperoni(int pepperoni){
        this.number_of_pepperoni_topping  =pepperoni;
    }
    public void setNumberOfHam(int ham){
        this.number_of_ham_topping = ham;
    }
    public String getSize(){
        return size_of_pizza;
    }
    public int getNumberOfCheese(){
        return number_of_cheese_topping ;
    }
    public int getNumberOfPepperoni(){
        return number_of_pepperoni_topping ;
    }
    public int getNumberOfHam(){
        return number_of_ham_topping;
    }
    public double calCost(){
        double cost;
        if(size_of_pizza=="large"){
            cost = 14 + (2*(getNumberOfCheese()+getNumberOfPepperoni()+getNumberOfHam()));
        }
        else if(size_of_pizza=="medium"){
            cost = 12 + (2*(getNumberOfCheese()+getNumberOfPepperoni()+getNumberOfHam()));
        }
        else{
            cost = 10 + (2*(getNumberOfCheese()+getNumberOfPepperoni()+getNumberOfHam()));
        }
        return cost;
    }
    public String getDescription(){
        return "Pizza size:"+getSize()+"\nCheese Toppings:"+getNumberOfCheese()+"\nPepperoni Toppings:"+getNumberOfPepperoni()+"\nHam Toppings:"+getNumberOfHam();
    }
    public void display(){
        calCost();
        
    }
   
   
    
}
