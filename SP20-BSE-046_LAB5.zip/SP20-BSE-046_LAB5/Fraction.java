/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fraction;
import java.util.Scanner;

/**
 *
 * @author Windows
 */
public class Fraction {
    public int X;
    public int Y;
    
    public Fraction(){
        X=0;
        Y=0;
    }
    public Fraction(int a,int b){
        X=a;
        Y=b;
    }
    public void setX(int a){
        X = a;
    }
     public int  setX(){
       return X;
    }
     public void setY(int b){
        X = b;
    }
     public int  setY(){
       return Y;
    }
    public void equals( Fraction C ){
        if(X/Y==C.X/C.Y){
            System.out.print("true");
        }
        else{
            System.out.println("false");
        }
        
        
    }
   public void display(){
       System.out.println(X);
       System.out.println(Y);
       
   }
    
}
