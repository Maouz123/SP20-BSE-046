/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computer;

/**
 *
 * @author Windows
 */
public class Laptop extends Computer {
    private double length;
    private double width;
    private double height;
    private double weight;
    
    public Laptop(){

    }
    public Laptop(double length, double width, double height, double weight){
        this.length = length;
        this.width = width;
        this.height = height;
        this.weight = weight;
    }
    public void setlength(){
        this.length=length;
        
    }
    public double getlength(){
        return this.length=length;
        
    }
    public void setwidth(){
        this.width=width;
        
    }
    public double getwidth(){
        return this.width=width;
        
    }
    public void setheigth(){
        this.height=height;
        
    }
    public double getheight(){
        return this.height=height;
        
    }
    public void setweight(){
        this.weight=weight;
        
    }
    public double getwordsize(){
        return this.weight=weight;
        
    }
    public void display(){
        System.out.println("Length: " + length+"cm\nWidth: " + width+"cm\nHeight: " + height+"cm\nWeight: " + weight+"kg");
    }
}
