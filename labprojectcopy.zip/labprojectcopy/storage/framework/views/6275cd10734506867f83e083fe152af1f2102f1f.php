<?php
   if(!isset($_SESSION)) 
   { 
       session_start(); 
   } 
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatibile" content="ie=edge">
  <meta name="Description" content="Enter your description here"/>
  <title>Cafe</title>
  <!-- bootstrap CDN-->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Smooch&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet"  type="text/css">
<!-- CSS-->
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" >

<link href="<?php echo e(asset('css/responsive-style.css')); ?>" rel="stylesheet" type="text/css" >

</head>

<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="100"> 
  <header>
  <nav class="navbar navbar-expand-lg navigation-wrap">
      <div class="container">
        <a class="navbar-brand" href="#">
          <h2 style="font-family:Smooch ; font-size:55px; ">Cafê</h2>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <!--  <span class="navbar-toggler-icon"></span>-->
         <i class="fas fa-stream navbar-toggler-icon "></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link  " aria-current="page" href="/">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link " href="/about">About Us</a>
            </li>
            <li> <div class="nav-item dropdown">
              <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Menu</a>
              <div class="dropdown-menu text-capitalize">
                  <a href="/bvg" class="dropdown-item">Beverages</a> 
                  <a href="/desserts" class="dropdown-item">Desserts</a> 
                  <a href="/snacks" class="dropdown-item">Snacks</a>
                  <a href="/deals" class="dropdown-item">Deals</a>
              </div>
          </div></li>
            <li class="nav-item">
              <a class="nav-link " href="/gall">Gallery</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/query">Contact Us</a>
            </li>
            <li><a href="/logincheck" ><button class="main-btn" >Sign-in</button></a></li>
     
          </ul>
        </div>
      </div>
    </nav>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item"><a class="act" href="menu.html">Menu</a></li>
      </ol>
    </nav>
  </header>

  <div class="menu">
    <h2>Cart</h2>
    <table id="table_customers">
      <thead>
            <tr class="customers_table">
              <th class="table_items">Item ID</th>
              <th class="table_items">Name</th>
              <th class="table_items">Price</th>
              <th class="table_items">Quantity</th>
              <th class="table_items">Total Price</th>
    
              <th class="table_items">Delete</th>
              <th class="table_items">Update</th>
            
            
            </tr>
</thead>
<tbody>
    

    <?php $__currentLoopData = $_SESSION; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      <td><?php echo e($loop->index); ?></td>
      <td><?php echo e($product[0]); ?></td>

      
          <input type='hidden' name='price' value='$value'>
      
          <td><?php echo e($product[1]); ?></td>
        
          <form action="<?php echo e(url('/update_cart_item',[$product[0]])); ?>" method="POST">
          <?php echo csrf_field(); ?>

          <td class='carttable'> <input type='text' name='quantity' value='<?php echo e($product[2]); ?>'> </td>
          
        
        <td><?php echo e($product[2] * $product[1]); ?></td>
      
      <td><button class='btncompord' type='submit'>Update</button></td>
      </form>

        <form action="<?php echo e(url('/delete_cart_item',[$product[0]])); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <td><button class='btncompord' type='submit'>Delete</button></td>
      </form>

      
      
      <tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
             
                    
       </table>
<button  class='btncompord1' ><a href="/bvg">Continue Shopping</a></button>

<form action="<?php echo e(url('/placeorder')); ?>" method="POST">
          <?php echo csrf_field(); ?>
<button class='btncompord2'  type="submit">Place order</button>
  </form>





</div>


 <!--Footer-->
 <footer class="footer" style="margin-top:300px">
    <div class="fcontainer">
      <div class="row">
        <div class="f-col">
          <h4>Cafê </h4>
          <ul>
            <li><a href="about.html">about us</a></li>
            <li><a href="#">menu</a></li>
            <li><a href="#">contact us</a></li>
            <li><a href="#">reviews</a></li>
          </ul>
         
        </div>
        <div class="f-col">
          <h4>get help</h4>
          <ul>
            <li><a href="#">FAQs</a></li>
            <li><a href="#">Order Status</a></li>
            <li><a href="#">Payment Options</a></li>
            <li><a href="#">Delivery Instructions</a></li>
          </ul>
        </div>
        <div class="f-col">
          <h4>Menu</h4>
          <ul>
            <li><a href="#">New Items</a></li>
            <li><a href="#">Eid Deals</a></li>
            <li><a href="#">Exclusive Deals</a></li>
            <li><a href="#">Reviews</a></li>
          </ul>
        </div>
        <div class="f-col">
          <h4>follow us</h4>
          <div class="social-links">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-linkedin-in"></i></a>

          </div>
         
        </div>
      </div>
    </div>
  </footer>
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\labprojectcopy\resources\views/cart.blade.php ENDPATH**/ ?>