<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Models\customer;
use App\Models\order;
use App\Models\register;
class customercontroller extends Controller
{

    function save(Request $request){
        $data= new register;
        $data->first_name=$request->input('first_name','a');
        $data->last_name=$request->input('last_name', 'b');
        $data->username=$request->input('username', 'xyz');
        $data->email=$request->input('email', 'ab@gmail.com');
        $data->password=$request->input('password');
        $data->phone=$request->input('phone', '1234');
        $data->address=$request->input("address", 'karachi');
      // DB::unprepared("insert into customers (first_name, last_name,email,phone, address) values ('$first_name', '$last_name,'$email','$phone','$address')");
        $data->save();
        return redirect('/register');
      
    }
  
    function saveadmin(Request $request){
      $data= new register;
      $data->first_name=$request->input('first_name','a');
      $data->last_name=$request->input('last_name', 'b');
      $data->username=$request->input('username', 'xyz');
      $data->email=$request->input('email', 'ab@gmail.com');
      $data->password=$request->input('password');
      $data->phone=$request->input('phone', '1234');
      $data->address=$request->input("address", 'karachi');
    // DB::unprepared("insert into customers (first_name, last_name,email,phone, address) values ('$first_name', '$last_name,'$email','$phone','$address')");
      $data->save();
      return view('admin/adminregister');
    
  }




    function store(Request $request){
      $data= new order;
      $data->time=$request->input('time');
      $data->date=date("Y/m/d");
      $data-> cust_id=$request->input('cust_id', '2');
      $data-> name=$request->input('name', '');
      $data-> status=$request->input('status', 'pending');
      $data-> quantity=$request->input('quantity', '1');
      $data-> price=$request->input('price', '');
      $data->total_amount=$request->input('total_amount', '1500');
    
    //  DB::unprepared("insert into queries (name,email,subject, message) values ('$name','$age','$class','$phone')");
      $data->save();
      return redirect('admin/order');
    
  }

   /* function display(){
      $customers = DB::select("select * from customers");
      return view('customers', ['customers'=>$customers]);
    }
*/
function display(){
  $data = customer::all();
  return view('admin/customer', ['customers'=>$data]);
}

function displayorder(){
  $order = order::all();
  return view('admin/vieworders', ['orders'=>$order]);
}

function displayorderdetail(){
  $orderdetail = DB:: select ('select * from orders where status = :status', ['status'=> 'completed']);

  
  //$orderdetail = order::all();
  return view('admin/orderdetail', ['orders'=>$orderdetail]);
}




  function destroy($id)
{
  DB::unprepared("delete from customers where cust_id = '$id'");
  return redirect('/customer');
}
function destroyorderdetail($id)
{
  DB::unprepared("delete from orders where order_id = '$id'");
  return redirect('vieworders');
}


/*function update(Request $req){
$data=customer::find($req->id);

$data->first_name=$req->has(first_name);
$data->last_name=$req->last_name;
$data->username=$req->username;
$data->email=$req->email;
$data->phone=$req->phone;
$data->address=$req->address;
$data->save();
return redirect('customer');
}*/


function update(Request $request) {


  $data= customer::find($request->id);
  $data->first_name=$request->first_name;
  $data->last_name=$request->input('last_name');
  $data-> username=$request->input('username');
  $data->email=$request->input('email');
  
  $data->phone=$request->input('phone');
  $data->address=$request->input('address');
  $data->save();
 

  /*$id=customer::find($request->id);
  $first_name= $request->first_name;
  $last_name= $request->input('last_name');
  $username= $request->input('username');
  $email= $request->input('email');
  $phone= $request->input('phone');
  $address= $request->input('address');


  DB::update("update customers set first_name=?, last_name=?, username=?,
  email=?, phone=?, address=? where cust_id=?", [$first_name, $last_name, $username, $email, $phone,$address, $id]);*/
  return redirect('/customer');
}

function show($id){

  $data = customer::find($id);
  return view('/admin/viewcustomers', ['customers'=>$data]);
}


/*update function for orders
function showorder($id){

  $data = order::find($id);
  return view('/admin/updateorder', ['orders'=>$data]);
}
function updateorder(Request $request) {


  $data= order::find($request->id);
  $data->orderName=$request->orderName;
  $data->status=$request->input('status');
  $data->total_amount=$request->input('username');
 
 
  $data->save();
}*/

function complete(Request $request)
{

  $data= order::find($request->id);
  if($data->status=="pending"){
 
  $data->status='completed';
  $data->save();
  return redirect('/vieworders');}
  

  //$data =  DB:: select ('select status from orders where status = :status', ['status'=> 'pending', 'completed'] );

  //$data->status = $req->str_replace('pending', ' ',  'completed');
  //['orders'=>$orderdetail];
 

 // $data->status = $new;
 // return redirect('/vieworders');
}


function adminprofile(Request $request){
  
  $data= customer::find($request->id);
  $data->first_name=$request->first_name;
  $data->last_name=$request->input('last_name');
  $data-> username=$request->input('username');
  $data->email=$request->input('email');
  
  $data->phone=$request->input('phone');
  $data->address=$request->input('address');
  $data->save();


}
}