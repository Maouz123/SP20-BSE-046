/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizza;

/**
 *
 * @author Windows
 */
public class Order {
     private Pizza O1;
    private Pizza O2;
    private Pizza O3;
    
    public Order(Pizza p1, Pizza p2,Pizza p3){
        this.O1 = p1;
        this.O2 = p2;
        this.O3 = p3;
    }
    public double calcTotal(){
        return O1.calCost() + O2.calCost()+ O3.calCost();
    }
    public void display(){
        calcTotal();
        
    }
    
}
