/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package publishing_company;

/**
 *
 * @author Windows
 */
public class tape extends Publishing_Company {
     private int playingTime;

    public tape(){

    }
    public tape(int playingTime){
        this.playingTime = playingTime;
    }
    public void setPlayingTime(int playingTime){
        this.playingTime = playingTime;
    }
    public int getPlayingTime(){
        return playingTime;
    }
    public void display(){
        System.out.println("the Playing time is: " + getPlayingTime()+" mins");
    }
}
