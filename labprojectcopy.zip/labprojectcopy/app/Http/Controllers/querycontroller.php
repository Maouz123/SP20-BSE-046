<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use App\Models\query;
class querycontroller extends Controller
{
    function sav(Request $request){
        $data= new query;
        $data->name=$request->input('name');
        $data->email=$request->input('email');
        $data-> subject=$request->input('subject');
        $data-> status='not answered';

        $data->message=$request->input('message');
        $data->date=date("Y/m/d");
      //  DB::unprepared("insert into queries (name,email,subject, message) values ('$name','$age','$class','$phone')");
        $data->save();
        return redirect('/query');
      
    }
    function view(){
     
    $data= query::all();
    return view('admin/queries',['queries'=>$data]);
    
  }
 
  function viewquery($id){
    $data= query::find($id);
    return view('admin/viewquery',['d'=>$data]);
    
  }

function savreply(Request $request){
 
  $data= query::find($request->id);
  if($data->status=="not answered"){
  $data->reply=$request->reply;
  $data->status='complete';
  $data->save();
  return redirect('/qlist');}
  else{
    return '<script>alert("this query has been answered")</script>';}

}
function delquery($id){
  $data= query::find($id);
  $data->delete();
  return redirect('/qlist');
}

function viewallrep(){
     
  $data= query::all();
  return view('viewallans',['queries'=>$data]);
  
}

}
