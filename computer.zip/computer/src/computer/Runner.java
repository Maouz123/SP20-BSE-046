/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computer;
import java.util.Scanner;

/**
 *
 * @author Windows
 */
public class Runner {
     public static void main(String[] args) {
         System.out.println("enter the size of word");
         Scanner input=new Scanner(System.in);
         Double W=input.nextDouble();
         System.out.println("enter the size of memory");
         Double M=input.nextDouble();
         System.out.println("enter the size of Storage");
         Double S=input.nextDouble();
         System.out.println("enter the speed");
         Double Sp=input.nextDouble();
         
         
        Computer C = new Computer(W,M,S,Sp);
        C.display();
        System.out.println("enter length");
         Double l=input.nextDouble();
         System.out.println("enter width");
         Double wdt=input.nextDouble();
         System.out.println("enter Height");
         Double H=input.nextDouble();
         System.out.println("enter weight");
         Double wi=input.nextDouble();
        Laptop L= new Laptop(l,wdt,H,wi);
        System.out.println();
        L.display();
    }
    
}
