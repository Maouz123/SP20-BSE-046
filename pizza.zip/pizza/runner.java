/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizza;

/**
 *
 * @author Windows
 */
public class runner {
    public static void main(String[] args){
        Pizza O1 = new Pizza("large",2,2,2);
        Pizza O2 = new Pizza("medium",3,3,3);
        Pizza O3 = new Pizza("small",4,4,4);
        Order O = new Order(O1,O2,O3);
        System.out.println("Cost of three ordered pizza is:$"+O.calcTotal());
        
    }
}
