<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\image;
class gallerycontroller extends Controller
{
    function saveimg(Request $request){
         $data= new image;
         $data->title=$request->input('name');
         $data->description=$request->input('description');
         $data->image=$request->file('photo')->getClientOriginalName();
         $data->save();
         return redirect('/img');
       
     }
     function view(){
     
        $data= image::all();
        return view('admin/viewgallery',['items'=>$data]);
        
      }
      function delimg($id){
        $data= image::find($id);
        $data->delete();
        return redirect('/viewgall');
      }
      function showimg($id){
        $data= image::find($id);
       
        return view('admin/editgallery',['itm'=>$data]);
      }
      function updateimg(Request $request){
        $data= image::find($request->id);
        $data->title=$request->input('name');
        $data->description=$request->input('description');
        if($request->file('photo')!=null){
            $data->image=$request->file('photo')->getClientOriginalName();}
        $data->save();
        return redirect('/viewgall');
      
    }
    function viewgallery(){
     
        $data= image::all();
        return view('gallery',['items'=>$data]);
        
      }
}
