/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package publishing_company;

/**
 *
 * @author Windows
 */
public class runner {
      public static void main(String[] args) {
        book Book = new book();
        tape Tape = new tape();
        Tape.setTitle("abc");
        Book.setTitle("xyz");
        Book.setPrice(Math.random()*500);
        Tape.setPrice(Math.random()*500);
        Book.setPageCount((int)(Math.random()*50));
        Tape.setPlayingTime((int)(Math.random()*100));
        Book.display();
        System.out.println();
        Tape.display();
    }
    
}
