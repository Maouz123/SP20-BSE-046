<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatibile" content="ie=edge">
  <meta name="Description" content="Enter your description here"/>
  <title>Cafe</title>
  <!-- bootstrap CDN-->
  
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet"  type="text/css">

<!-- CSS-->

<link href="<?php echo e(asset('admincss/style.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(asset('admincss/admin_style.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(asset('admincss/responsive-style.css')); ?>" rel="stylesheet" type="text/css" >


<link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Smooch&display=swap" rel="stylesheet">
<style>
  .bckimg{
    background: url("../Images/conn.jpg") no-repeat center  ;
    background-size:cover;
    margin-bottom:5px;}
</style>


</head>

<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="100"> 
  <!--Header-->
  <header>
    <nav class="navbar navbar-expand-lg navigation-wrap">
      <div class="container">
        <a class="navbar-brand" href="#">
          <h2 style="font-family:Smooch ; font-size:55px; margin-left: 30px; ">Cafê</h2>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <!--  <span class="navbar-toggler-icon"></span>-->
         <i class="fas fa-stream navbar-toggler-icon "></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            
            <li><a href="#" ><button class="main-btn" >Logout</button></a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <div class="wrapper">
    <div class="sidebar">
    
        <img class="adminlogo"   src="<?php echo e(asset('Images/admin.png')); ?>">
        
        <ul>
            <li  ><a  href="/adminindex"><i class="fas fa-home"></i>Home</a></li>
            <li><a href="#"><i class="fas fa-user"></i>Profile</a></li>
           
            <li><a href="/vieworders"><i class="fa-solid fa-basket-shopping"></i>Orders</a></li>
            <li><a href="/viewquery"><i class="fa-solid fa-clipboard-list"></i>Queries</a></li>
            <li id="active"><a href="/customer"><i class="fa-solid fa-people-group"></i>Customers</a></li>
            <li><a href="/viewitems"><i class="fa-solid fa-bell-concierge"></i>Menu Items</a></li>
            <li><a href="/viewgallery"><i class="fa-solid fa-camera-retro"></i>Gallery</a></li>
        </ul> 
      
      
    </div>
 
  <div class="main_content">
    <h2 class="adminheading">View Customer</h2>
  
    <form id="query_form" action="/update" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-lg-6">

    <input type="hidden" class="form-control"  name="cust_id" value=<?php echo e($customers['cust_id']); ?> ></input>

    <p>First Name</p>
    <input type="text" class="" id="name1" name="first_name" value=<?php echo e($customers['first_name']); ?> required />

   

      <label for="username">Username</label><br>
      <input type="text" class="form-control" name="username" value=<?php echo e($customers['username']); ?>  > <br>
</input>
<label for="phone">Phone</label><br>
      <input type="text" class="form-control"  name="phone" value=<?php echo e($customers['phone']); ?> > <br>
</input>
  </div>
  <div class="col-lg-6">    
  <label for="last_name">Last Name</label><br>
      <input type="text" class="form-control" name="last_name" value=<?php echo e($customers['last_name']); ?>> </input><br>

      
<label for="email">Email</label><br>
      <input type="text" class="form-control"  name="email" value=<?php echo e($customers['email']); ?> > <br>
</input>



<label for="address">Address</label><br>
   
      <input type="text" class="form-control"  name="address" value=<?php echo e($customers['address']); ?> > 
</input>
  </div>
  </div>

    <div>
        <button class="main-btn" type="submit" id="sendMessageButton">Update</button>
        <button class="main-btn" type="submit" id="sendMessageButton"><a href="/customers" style="color: black">Back</a></button>
    </div>
  </form>
  </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\Aneeza Amanat\Desktop\labproject\resources\views//admin/viewcustomers.blade.php ENDPATH**/ ?>