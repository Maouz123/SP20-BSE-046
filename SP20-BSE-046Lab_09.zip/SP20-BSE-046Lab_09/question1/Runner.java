/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clock;

/**
 *
 * @author Windows
 */
public class Runner {
            public static void main(String[] args) {
            ClockExtended time=new ClockExtended("00","35","30");
            time.display();
        }
    
}
