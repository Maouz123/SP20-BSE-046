<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\querycontroller;
use App\Http\Controllers\itemcontroller;
use App\Http\Controllers\logincontroller;
use App\Http\Controllers\gallerycontroller;
use App\Http\Controllers\cartcontroller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return view('index');
});

Route::get('/contact', function () {
    return view('query');
});
Route::view('/about','about');
Route::post('/query','App\Http\Controllers\querycontroller@sav');
Route::view('/query','query');

Route::get('/qlist','App\Http\Controllers\querycontroller@view');
Route::get('/viewquery/{id}','App\Http\Controllers\querycontroller@viewquery');
Route::view('/viewquery','admin/viewquery');

Route::get('deleteq/{id}','App\Http\Controllers\querycontroller@delquery');
Route::post('/viewquery','App\Http\Controllers\querycontroller@savreply');

Route::post('/additem','App\Http\Controllers\itemcontroller@save');
Route::view('/item','admin/additem');
Route::get('/itmlist','App\Http\Controllers\itemcontroller@view');
Route::get('deleteitm/{id}','App\Http\Controllers\itemcontroller@delitm');
Route::get('edit/{id}','App\Http\Controllers\itemcontroller@showitm');
Route::post('/edit','App\Http\Controllers\itemcontroller@updateitm');


Route::get('/bvg','App\Http\Controllers\itemcontroller@beverages');
Route::get('/snacks','App\Http\Controllers\itemcontroller@snacks');
Route::get('/deals','App\Http\Controllers\itemcontroller@deals');
Route::get('/desserts','App\Http\Controllers\itemcontroller@desserts');

Route::get('/login','App\Http\Controllers\logincontroller@login');
Route::get('/logincheck','App\Http\Controllers\logincontroller@logincheck');
Route::view('/login', 'login');
Route::post('/usrlogin','App\Http\Controllers\logincontroller@logindata');

Route::get('/adminlogin','App\Http\Controllers\logincontroller@loginadmindata');
Route::post('/adminlogin','App\Http\Controllers\logincontroller@loginadmindata');

Route::view('/profile','profile');
Route::view('/adminprofile','admin/adminprofile');

Route::get('/logout','App\Http\Controllers\logincontroller@logout');
Route::view('/img','admin/addimg');

Route::post('/imgpost','App\Http\Controllers\gallerycontroller@saveimg');


Route::get('/viewgall','App\Http\Controllers\gallerycontroller@view');
Route::get('deleteimg/{id}','App\Http\Controllers\gallerycontroller@delimg');
Route::get('editimg/{id}','App\Http\Controllers\gallerycontroller@showimg');
Route::post('/updimg','App\Http\Controllers\gallerycontroller@updateimg');

Route::get('/gall','App\Http\Controllers\gallerycontroller@viewgallery');

//Admin side views, staring from customer

Route::get('/adminindex', function () {
    return view('/admin/adminindex');
});


Route::post('/register','App\Http\Controllers\customercontroller@save');
Route::view('/register','register');
Route::get('/register', function () {
    return view('register');
});

Route::post('/adminregister','App\Http\Controllers\customercontroller@saveadmin');
Route::view('/adminregister','admin/adminregister');
Route::get('/adminregister', function () {
    return view('admin/adminregister');
});

Route::post('/order','App\Http\Controllers\customercontroller@store' );
Route::view('/order','order');
Route::get('/order', function () {
    return view('order');
});


Route::get('/customer','App\Http\Controllers\customercontroller@display' );
//Route::view('/customer','customer');





Route::get('delete/{id}', 'App\Http\Controllers\customercontroller@destroy');


Route::get('delete1/{id}', 'App\Http\Controllers\customercontroller@destroyorderdetail');



Route::get('update/{id}', 'App\Http\Controllers\customercontroller@show');
Route::post('/update', 'App\Http\Controllers\customercontroller@update');


//Route::get('update/{id}', 'App\Http\Controllers\querycontroller@updatecus');



Route::get('/vieworders','App\Http\Controllers\customercontroller@displayorder' );

Route::get('/orderdetail','App\Http\Controllers\customercontroller@displayorderdetail' );
//Route::view('/orderdetail', ['status' => 'completed']);




//cart

Route::get('/cart', function () {
    return view('cart');
});

//Route::get('mycart/{id}', 'App\Http\Controllers\cartcontroller@showCart');

Route::post('/mycart/{id}', 'App\Http\Controllers\cartcontroller@addToCart');
Route::post('/cart', 'App\Http\Controllers\cartcontroller@editcart');
//Route::post('/cart', 'App\Http\Controllers\cartcontroller@editcart');

Route::post('/delete_cart_item/{name}', 'App\Http\Controllers\cartcontroller@deleteItem');
Route::post('/update_cart_item/{name}', 'App\Http\Controllers\cartcontroller@updateItem');

Route::post('/placeorder', 'App\Http\Controllers\cartcontroller@placeorder');

Route::get('/remove', 'App\Http\Controllers\cartcontroller@remove');


Route::get('complete/{id}', 'App\Http\Controllers\customercontroller@complete');

Route::get('/adminlogin', function () {
    return view('/admin/adminlogin');
});

Route::get('/myprofile', 'App\Http\Controllers\profilecontroller@displayyprofile');
Route::get('/vans','App\Http\Controllers\querycontroller@viewallrep');