/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fraction;

/**
 *
 * @author Windows
 */
public class Runner {
    public static void main(String[] arg){
        Fraction f1 = new Fraction();
        Fraction f2 = new Fraction(44,3);
        f1.setX(25);
        f1.setY(4);
        f1.display();
        f2.display();
        
        System.out.println();
    
        
    }
    
}
