<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use Session;
use DateTime; 
use App\Models\order;
use App\Models\item;
use view\beverages;

class cartcontroller extends Controller
{
    
   public function showCart($id){
        $data = item::find($id);
       // echo($data);
    
        return  ( ['items'=>$data]);
    }
  
    
   
 /*   public function addToCart(Request $request){
            $data= item::find($request->id);
            $data->name=$request->name;
            $data->price=$request->input('price');
            $data-> quantity=$request->input('quantity');
            
            $data->img=$request->input('img');
            $data->save();
            return redirect('/cart');
 
    }*/

    
    public function addToCart(Request $request, $id)
    { 
        $data = item::find($id);
    
        session_start();
       
         $name=$data->name;
         $price=$data->price;
       // $quantity=$_POST['qty'];
        $quantity=$request->input('qty');
      
        $product = array($name, $price, $quantity);
       // print_r($product);
       
        $_SESSION[$name] = $product;

  
       return redirect ('/bvg');
    }

    public function deleteItem(Request $request, $name)
    { 
        session_start();
        unset($_SESSION[$name]);
        return back();
    }

    public function updateItem(Request $request, $name)
    { 
        session_start();
        $new_quantity = $request->input('quantity');

        $data = $_SESSION[$name];

        $data[2] = $new_quantity;

        $_SESSION[$name] = $data;

        return back();
    }

    

    public function placeorder(Request $request){
        if( session()->has('user')){
      
        session_start();
   

             foreach($_SESSION as $product){
            
            $data= new order;
                
                    $data->name =$product[0];
                    $data->price=$product[1]; 
                    $data->quantity= $product[2];
                  
        $data->cust_id=$request->input('cust_id', '6');

        $data->date = new DateTime();
        $data-> status=$request->input('status', 'pending');
        
        $data->total_amount=$data->price * $data->quantity;
        $data->save(); 
        
        unset($_SESSION[$data->name]);
             }
    }
    else{
        return redirect('/login');
    }
      //  DB::unprepared("insert into queries (name,email,subject, message) values ('$name','$age','$class','$phone')");
        
      return back();
    }

    
}
