<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Models\customer;
use App\Models\admin;
class logincontroller extends Controller
{
    function logindata(Request $r){
        $name=$r->input('first_name');
        
        $password= $r->input('password');
         $cus = customer::all();
      //  $data=$r->input();
      // $cus = customer::where('first_name', $name)->get();
      
      foreach($cus as $data){
        if(($data->first_name==$name) && ($data->password==$password)){
            $r->session()->put('user', $name);
            return redirect('/profile');
         
        }

        
        
      }
      
      return redirect('/login');
       
       
    }

    function logincheck(Request $r){
       
        if( session()->has('user')){
            return redirect ('/profile');
        }
        else{
            return redirect ('/login');
        }
    }




    function loginadmindata(Request $r){
        $name=$r->input('first_name');
        
        $password= $r->input('password');
         $cus = admin::all();
      //  $data=$r->input();
      // $cus = customer::where('first_name', $name)->get();
      
      foreach($cus as $data){
        if(($data->first_name==$name) && ($data->password==$password)){
            $r->session()->put('user', $name);
            return redirect('/adminindex');
           
        }

        
        
      }
      
      return redirect('/adminlogin');
       
    }

    function login(){
        if( session()->has('user')){
            return redirect ('/login');
        }
        return view('login');
    }
    function loginadm(){
        if( session()->has('user')){
            return redirect ('/');
        }
        return view('login');
    }



    function logout(){
        if( session()->has('user')){
            session()->pull('user');

        }
        return redirect('login');
    }
   
}
